﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise11
{
    class Extension
    {
        /// <summary>
        /// Function to make a check for odd number
        /// </summary>
        /// <param name="number"></param>
        public static void OddNum(int number)
        {
            bool oddnum = number.IsOdd();
            Console.WriteLine("Odd Number - " + oddnum);
        }
        
        /// <summary>
        /// Function to make a check for even number
        /// </summary>
        /// <param name="number"></param>
        public static void EvenNum(int number)
        {
            bool evennum = number.IsEven();
            Console.WriteLine("Even Number - " + evennum);
        }
        
        /// <summary>
        /// Function to make a check for Prime number
        /// </summary>
        /// <param name="number"></param>
        public static void PrimeNum(int number)
        {
            bool primenum = number.IsPrime();
            Console.WriteLine("Prime Number - " + primenum);
        }

        /// <summary>
        /// Function to make a check is number is divisible by another number.
        /// </summary>
        /// <param name="number"></param>
        public static void IsDivisibleBy(int number)
        {
            int divisible = int.Parse(Console.ReadLine());
            bool divisiblenum = number.IsDivisibleBy(divisible);
            Console.WriteLine("Is Divisible By " + divisible + " : " + divisiblenum);
        }
        
        static void Main(string[] args)
        {
            var number = int.Parse(Console.ReadLine());

            OddNum(number);

            EvenNum(number);

            PrimeNum(number);

            IsDivisibleBy(number);
        }
    }
}
