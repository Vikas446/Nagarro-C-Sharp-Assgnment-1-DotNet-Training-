﻿/*using System;

namespace Assignment_1
{
    class Exercize_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number : ");

            // For Integer

            string input = Console.ReadLine();

            int int_converted_1 = int.Parse(input);
            int int_converted_2 = Convert.ToInt32(input);
            bool int_result = int.TryParse(input, out Int32 i);

            Console.WriteLine(int_converted_1+" "+int_converted_2+" "+int_result);

            // For Float

            string input_float = Console.ReadLine();

            bool float_converted = float.TryParse(input_float, out Single res);
            float float_converted_1 = Convert.ToSingle(input_float);
            float float_converted_2 = float.Parse(input_float);

            Console.WriteLine(float_converted + " " + float_converted_1 + " " + float_converted_2);


        }
    }
}
*/