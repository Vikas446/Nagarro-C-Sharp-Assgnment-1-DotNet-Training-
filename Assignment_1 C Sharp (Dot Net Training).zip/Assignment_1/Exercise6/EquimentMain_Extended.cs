﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise6
{
    public class EquipmentMain_Extended
    {
        static void Main(string[] args)
        {
            var mobile_obj = new Mobile();
            var immobile_obj = new IMobile();
            int num;
            Console.WriteLine("1. Create An Equipment - Mobile / Immobile");
            Console.WriteLine("2. Delete An Equipment");
            Console.WriteLine("3. Move an Equipment - Mobile / Immobile");
            Console.WriteLine("4. List of all Equipments");
            Console.WriteLine("5. Show Details of an Equipment");
            Console.WriteLine("6. List of all Mobile Equipment -> Using Lambda");
            Console.WriteLine("7. List of all Immobile Equipment -> Using Lambda");
            Console.WriteLine("8. All Equipments that have not been Moved");
            Console.WriteLine("9. Delete All Equipment");
            Console.WriteLine("10. Delete All Immobile Equipment");
            Console.WriteLine("11. Delete All Mobile Equipment");
            Console.WriteLine("12. Exit");
            
            do
            {
                string str = Console.ReadLine();
                num = Convert.ToInt32(str);

                switch (num)
                {
                    case 1:

                        Console.WriteLine("Select 1 for Mobile : ");
                        Console.WriteLine("Select 2 for Immobile : ");
                        int createequip= int.Parse(Console.ReadLine());

                        if (createequip == 1)
                        {
                            mobile_obj.CreateEquipment();
                            //Console.WriteLine("Enter Distance travelled : ");
                            //string str_mobile = Console.ReadLine();
                            //int dist_mobile = Convert.ToInt32(str_mobile);
                            //mobile_obj.MoveBy(dist_mobile);
                            //equip.Add(mobile_obj);
                            //mobile_obj.ShowDetails();
                        }
                        else
                        {
                            immobile_obj.CreateEquipment();
                            //Console.WriteLine("Enter Distance travelled : ");
                            //string str_immobile = Console.ReadLine();
                            //int dist_immobile = Convert.ToInt32(str_immobile);
                            //immobile_obj.MoveBy(dist_immobile);
                            //equip.Add(immobile_obj);
                            //immobile_obj.ShowDetails();
                        }
                        break;

                    case 2:
                        break;

                    case 3:

                        Console.WriteLine("1 For Mobile ");
                        Console.WriteLine("2 For Immobile ");
                        int moveequip = int.Parse(Console.ReadLine());

                        if (moveequip==1)
                        {

                        }


                        break;
                }

            } while (num!=12);
        }
    }
}
