﻿namespace Exercise6
{
    public abstract class Equipment_Extended
    {
        public string name, desc;
        public int distance_moved, maintainence_cost;
        public enum EquipmentType
        {
            Mobile = 1,
            Imobile = 2,
        }

        public Equipment_Extended()
        {
            distance_moved = maintainence_cost = 0;
        }

        public virtual void MoveBy(int distance)
        {
        }
    }
}
