﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise12
{
    class DelegatesExample
    {
        /// <summary>
        /// Creating Delegates
        /// </summary>
        /// <param name="numberlist"></param>
        
        public delegate void OddDelegate(List<int> numberlist);

        public delegate void EvenDelegate(List<int> numberlist);

        public delegate void PrimeAnonymous(List<int> numberlist);

        public delegate void PrimeLambda(List<int> numberlist);

        public delegate void GreaterThan5_MethodGroup(List<int> numberlist);
        
        /// <summary>
        /// To Find Odd Numbers Using Lambda Expression
        /// </summary>
        /// <param name="list"></param>
        public static void Odd(List<int> list)
        {
            var oddnumbers = list.Where(n => n % 2 != 0);
            foreach(var number in oddnumbers)
            {
                Console.Write(number+" ");
            }
        }

        /// <summary>
        /// To Find Even Numbers Using Lambda Expression
        /// </summary>
        /// <param name="list"></param>
        public static void Even(List<int> list)
        {
            var evennumbers = list.Where(n => n % 2 == 0) ;
            foreach (var number in evennumbers)
            {
                Console.Write(number + " ");
            }
        }

        /// <summary>
        /// To Find Prime Numbers in list Using Lambda Expression
        /// </summary>
        /// <param name="list"></param>
        public static void Prime(List<int> list)
        {
            Console.WriteLine("Prime using Lambda");
        }
       
        public static void Greaterthan5(List<int> list)
        {
            var numbergreaterthan5 = list.Where(n => n>5);
            foreach (var number in numbergreaterthan5)
            {
                Console.Write(number + " ");
            }
        }

        /// <summary>
        /// Main Method
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            List<int> list = new List<int>();

            for(int i = 1; i <= 10; i++)
            {
                list.Add(i);
            }
  
            var oddobj = new OddDelegate(Odd);
            oddobj.Invoke(list);

            Console.WriteLine();

            var evenobj = new EvenDelegate(Even);
            evenobj.Invoke(list);

            Console.WriteLine();
            
            // Anonymous Function 
            PrimeAnonymous prime = delegate (List<int> numberlist)
            {
                Console.WriteLine("Prime Using Anonymous");
            };
            prime(list);

            PrimeLambda primeobj = new PrimeLambda(Prime);
            primeobj.Invoke(list);

            GreaterThan5_MethodGroup greaterthan5obj = Greaterthan5;
            greaterthan5obj.Invoke(list);

            Console.WriteLine();


        }
    }
}
