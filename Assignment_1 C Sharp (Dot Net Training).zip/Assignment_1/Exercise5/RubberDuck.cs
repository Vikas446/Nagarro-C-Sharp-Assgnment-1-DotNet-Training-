﻿using System;

namespace Exercise5
{
    class RubberDuck : Duck, ISpeakingDuck
    {
        public RubberDuck(int weight, int wings) : base(DuckType.rubber, weight, wings)
        {

        }
        public void Speak()
        {
            Console.WriteLine("Rubber Duck Squeaks");
        }
    }
}
