﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise5
{
    interface IFlyingDuck
    {
        void Fly();
    }

    interface ISpeakingDuck
    {
        void Speak();
    }
    class DuckMain
    {
        static void ShowDetails(Duck obj)
        {
            string str = string.Format("Weight = {0} and Wings = {1}", obj.Weight, obj.Wings);
            Console.WriteLine(str);

            if (obj is IFlyingDuck fd)
            {
                fd.Fly();
            }

            if (obj is ISpeakingDuck sd)
            {
                sd.Speak();
            }
        }
        static void Main(string[] args)
        {
            var rd = new RubberDuck(4, 7);
            ShowDetails(rd);
        }
    }
}
