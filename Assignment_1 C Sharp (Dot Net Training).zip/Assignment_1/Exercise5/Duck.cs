﻿namespace Exercise5
{
    public abstract class Duck
    {
        public enum DuckType
        {
            rubber = 1,
            mallard = 2,
            redhead = 3
        }

        int weight;
        int wings;
        DuckType type;

        public int Weight
        {
            get
            {
                return weight;
            }
        }
        public int Wings
        {
            get
            {
                return wings;
            }
        }

        public Duck(DuckType type, int weight, int wings)
        {
            this.weight = weight;
            this.wings = wings;
            this.type = type;
        }

    }
}
