﻿using System;

namespace Exercise5
{
    class RedHeadduck : Duck, IFlyingDuck, ISpeakingDuck
    {
        public RedHeadduck(int weight, int wings) : base(DuckType.redhead, weight, wings)
        {

        }
        public void Speak()
        {
            Console.WriteLine("Red Head Duck Quacks Mild");
        }
        public void Fly()
        {
            Console.WriteLine("And Fly Slow.");
        }
    }
}
