﻿using System;

namespace Exercise5
{
    class MallardDuck : Duck, IFlyingDuck, ISpeakingDuck
    {
        public MallardDuck(int weight, int wings) : base(DuckType.mallard, weight, wings)
        {

        }
        public void Speak()
        {
            Console.WriteLine("Mallard Duck Quacks");
        }
        public void Fly()
        {
            Console.WriteLine("And Fly Fast.");
        }
    }
}
