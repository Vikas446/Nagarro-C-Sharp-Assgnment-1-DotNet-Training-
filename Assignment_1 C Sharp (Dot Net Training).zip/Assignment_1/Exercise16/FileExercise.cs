﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise16
{
    class FileExercise
    {
        static void Main(string[] args)
        {
            int length = 0;

            var path = @"C:\Users\manikkapoor\Desktop\ExampleFiles";
            FileInfo fileobj = new FileInfo(path);

            Console.WriteLine("1. ");
            string[] textfiles = Directory.GetFiles(path, "*.txt");

            foreach(var file in textfiles)
            {
                Console.WriteLine(file);
            }
            Console.WriteLine("2.");
            string[] allfiles = Directory.GetFiles(path, ".");

            foreach (var file in allfiles)
            {
                length = Math.Max(length, file.Length);
                Console.WriteLine(file.Length);
                Console.WriteLine(file);
            }
            Console.WriteLine("3. ");

            Console.WriteLine("4. ");
            Console.WriteLine("Maximum Length : "+length);
        }
    }
}
