﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise17
{
    class CustomException : Exception
    {
        public CustomException(string message):base(string.Format(message))
        {

        }
    }
    class Game
    {
        static void Main(string[] args)
        {
            int count = -1;
            try
            {
                Console.WriteLine("Enter a number between 1-5 ");
                int number = int.Parse(Console.ReadLine());

                switch (number)
                {
                    case 1:
                        Console.WriteLine("Enter Even Number");
                        int even = int.Parse(Console.ReadLine());

                        if (ValidateEven(even))
                        {
                            Console.WriteLine("Success !!");
                        }
                        break;

                    case 2:
                        Console.WriteLine("Enter Odd Number");
                        break;

                    case 3:
                        Console.WriteLine("Enter a prime number");
                        break;

                    case 4:
                        Console.WriteLine("Enter a negative number");
                        break;

                    case 5:
                        Console.WriteLine("Enter Zero");
                        break;

                    default:
                        Console.WriteLine("Enter Correct Number !!");
                        break;
                }
            }
            catch (CustomException ex)
            {
                Console.WriteLine(ex);
            }
        }
        private static bool ValidateEven(int evennumber)
        {
            return (evennumber % 2 == 0) ? true : throw new CustomException("Wrong Input !!");
        }
    }
}
