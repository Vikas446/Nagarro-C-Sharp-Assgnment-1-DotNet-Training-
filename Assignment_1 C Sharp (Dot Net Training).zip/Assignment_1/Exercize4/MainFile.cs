﻿/*using System;
using static Assignment_1.Exercize4.Equipment;

namespace Assignment_1
{
    class Exercize_4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select Your Choice : ");
            Console.WriteLine("1. Create an Equipment");
            Console.WriteLine("2. Move an Equipment");
            Console.WriteLine("3. Show Details of Equipment");
            Console.WriteLine("4. Press 4 to Exit");

            var str = Console.ReadLine();
            int num = Convert.ToInt32(str);

            do
            {
                switch (num)
                {
                    case 1:
                    

                    break;
                }

            } while (num!=4);
        }
    }
}*/