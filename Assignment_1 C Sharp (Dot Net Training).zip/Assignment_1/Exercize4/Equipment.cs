﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1.Exercize4
{
    class Equipment
    {
        public string Name, description;
        public float distance_moved;
        public float Maintainence;
        public enum Typeofequipment
        {
            Jcb=1,
            Jeep=2,
            Car=3,
            Tractor=4,
            Trolley=5,
            Ladder=6
        }

        Equipment()
        {
            distance_moved = Maintainence = 0.0f;
        }

        void SetEquipmentDetails()
        {
            Console.WriteLine("Enter Name of Equipment : ");
            Name = Console.ReadLine();

            Console.WriteLine("Enter Description : ");
            description = Console.ReadLine();

            Console.WriteLine("Select type : ");
            Console.WriteLine("1. Jcb");
            Console.WriteLine("2. Jeep");
            Console.WriteLine("3. Car");
            Console.WriteLine("4. Tractor");
            Console.WriteLine("5. Trolley");
            Console.WriteLine("6. Ladder");

            string str = Console.ReadLine();
            int type = Convert.ToInt32(str);

            
        }
    }
}
