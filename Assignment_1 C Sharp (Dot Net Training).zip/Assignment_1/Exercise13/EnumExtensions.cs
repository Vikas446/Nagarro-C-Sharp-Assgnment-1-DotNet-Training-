﻿using System.Collections.Generic;

namespace Exercise13
{
    public static class EnumExtensions
    {
        public static IEnumerable<int> CustomAll(this IEnumerable<int> list)
        {
            int count = 1;
            yield return count;
        }
        public static IEnumerable<int> CustomAny(this IEnumerable<int> list)
        {
            int count = 2;
            yield return count;
        }
        public static IEnumerable<int> CustomMax(this IEnumerable<int> list)
        {
            int count = 3;
            yield return count;
        }
        public static IEnumerable<int> CustomMin(this IEnumerable<int> list)
        {
            int count = 4;
            yield return count;
        }
        public static IEnumerable<int> CustomWhere(this IEnumerable<int> list)
        {
            int count = 5;
            yield return count;
        }
        public static IEnumerable<int> CustomSelect(this IEnumerable<int> list)
        {
            int count = 6;
            yield return count;
        }
    }
}
