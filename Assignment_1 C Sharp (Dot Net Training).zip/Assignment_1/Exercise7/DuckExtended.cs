﻿using System;
using System.Collections.Generic;

namespace Exercise5
{
    /// <summary>
    /// An Enum Representation to Represent Different Duck Types.
    /// </summary>
    public enum DuckType
    {
        rubber = 1,
        mallard = 2,
        redhead = 3
    }
    /// <summary>
    /// Class duck specifying it's properties.
    /// </summary>
    public abstract class Duck
    {
        int weight;
        int wings;
        DuckType type;

        /// <summary>
        /// Since Weight declared above is private by default, restricting from outer access.
        /// </summary>
        public int Weight
        {
            get
            {
                return weight;
            }
        }
        public int Wings
        {
            get
            {
                return wings;
            }
        }

        /// <summary>
        /// Constructor for class duck.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="weight"></param>
        /// <param name="wings"></param>
        public Duck(DuckType type, int weight, int wings)
        {
            this.weight = weight;
            this.wings = wings;
            this.type = type;
        }

    }

    /// <summary>
    /// Interface for representing which ducks can fly.
    /// </summary>
    interface IFlyingDuck
    {
        void Fly();
    }

    /// <summary>
    /// Interface for representing which ducks can speak.
    /// </summary>
    interface ISpeakingDuck
    {
        void Speak();
    }
    class DuckExtended
    {
        /// <summary>
        /// Method to Show details for respective ducks.
        /// </summary>
        /// <param name="obj"></param>
        static void ShowDetails(Duck obj)
        {
            if (obj is IFlyingDuck fd) fd.Fly();

            if (obj is ISpeakingDuck sd) sd.Speak();
        }
        static void Main(string[] args)
        {
            // Adding Ducks.
            var rd_obj1 = new RubberDuck(5, 7);
            var rd_obj2 = new RubberDuck(4, 7);
            var md_obj1 = new MallardDuck(4, 6);
            var md_obj2 = new MallardDuck(3, 4);
            var red_obj1 = new RedHeadduck(6, 7);
            var red_obj2 = new RedHeadduck(6, 2);

            List<Duck> duck = new List<Duck>();
            duck.Add(rd_obj1);
            duck.Add(rd_obj2);
            duck.Add(md_obj1);
            duck.Add(md_obj2);
            duck.Add(red_obj1);
            duck.Add(red_obj2);

            foreach(var d in duck)
            {
                Console.WriteLine("Weight - "+d.Weight+" Wings - "+d.Wings+" Type - ");
                //ShowDetails(d);
                //Console.WriteLine();
            }
            Console.WriteLine();
            //Removing Single Duck.

            //duck.Remove(rd_obj1);

            duck.Sort((d1,d2)=>d1.Weight.CompareTo(d2.Weight));
            
            foreach (var d in duck)
            {
                Console.WriteLine("Weight - " + d.Weight + " Wings - " + d.Wings + " Type - ");
                //ShowDetails(d);
                //Console.WriteLine();
            }
            Console.WriteLine();
            duck.Sort((d1, d2) => d1.Wings.CompareTo(d2.Wings));

            foreach (var d in duck)
            {
                Console.WriteLine("Weight - " + d.Weight + " Wings - " + d.Wings + " Type - ");
                //ShowDetails(d);
                //Console.WriteLine();
            }
        }
    }
}
